import java.net.*;
import java.io.*;
import java.util.*;

public class Server {
    public static void main(String[] args) throws IOException {
        int port = 8080;
        ServerSocket ss = new ServerSocket(port);
        Socket cs = ss.accept();
        PrintWriter out = new PrintWriter(cs.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(cs.getInputStream()));
        String str = in.readLine();
        if (str.equals("0")) {
            File dir = new File(System.getProperty("user.dir"));
            String list[] = dir.list();
            for (String l : list) {
                out.println(l);
            }
        } else {
            Date date = new Date();
            out.println(date);
        }
    }
}