import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

class Client {
    
    public static void main(String args[]) throws UnknownHostException, IOException {
        int port = 8080;
        Socket cs = new Socket("127.0.0.1", port);
        PrintWriter out = new PrintWriter(cs.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(cs.getInputStream()));
        String command = "1";
        out.println(command);
        String input = in.readLine();
        System.out.println(input);
    }
}